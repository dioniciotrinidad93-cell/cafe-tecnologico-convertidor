# Música antigua — Café Tecnológico

Paquete de prueba con 8 pistas de piano solo, música clásica antigua,
para usar como fondo de diálogos en la app convertidora de Café Tecnológico.

Fecha de descarga y preparación: 11 de noviembre de 2026.
Formato: MP3, 128 kbps, estéreo, 44.100 Hz.
Duración total: 19 minutos 12 segundos.
Tamaño total del zip: 18,3 MB.

## Cómo se preparó cada pista

Todas las grabaciones son modernas de Musopen o de la colección Musopen
en Internet Archive. No son grabaciones antiguas de disco: son
interpretaciones actuales liberadas al dominio público o con licencia
Creative Commons. Por eso no tenían siseo, crujidos ni zumbido: se
comprobó el silencio al inicio de cada archivo y no se encontró ruido
que limpiar, así que no se aplicó una limpieza fuerte, para no dejar
sonido metálico. Solo se hizo, en cada pista:

- Quitar el silencio del inicio.
- Recortar a un fragmento tranquilo de 120 a 150 segundos
  (la de Mozart se dejó completa, dura 2 minutos 12 segundos).
- Un filtro suave contra ruido de fondo y contra frecuencias muy bajas.
- Normalizar todas al mismo nivel bajo, unas -20 LUFS, para que
  ninguna tape la voz del diálogo.
- Fundido de entrada de 2 segundos y fundido de salida de 3 segundos.

En el Preludio "Gota de lluvia" de Chopin solo se tomó el inicio
tranquilo (2 minutos): la parte del medio es fuerte y no sirve de fondo.

## Las 8 pistas

### 1. 01-beethoven-claro-de-luna.mp3 — 2 minutos 30 segundos, 2,29 MB
- Compositor: Ludwig van Beethoven
- Obra: Sonata para piano número 14 en do sostenido menor, Opus 27 número 2, "Claro de luna", primer movimiento, Adagio sostenuto
- Intérprete: Paul Pitman
- Fuente: https://commons.wikimedia.org/wiki/File:Ludwig_van_Beethoven_-_sonata_no._14_in_c_sharp_minor_%27moonlight%27,_op._27_no._2_-_i._adagio_sostenuto.ogg
- Licencia de la grabación: dominio público (Musopen)
- Fecha de descarga: 11 de noviembre de 2026

### 2. 02-beethoven-patetica-adagio.mp3 — 2 minutos 30 segundos, 2,29 MB
- Compositor: Ludwig van Beethoven
- Obra: Sonata para piano número 8 en do menor, Opus 13, "Patética", segundo movimiento, Adagio cantabile
- Intérprete: Paul Pitman
- Fuente: https://commons.wikimedia.org/wiki/File:Beethoven,_Sonata_No._8_in_C_Minor_Pathetique,_Op._13_-_II._Adagio_cantabile.ogg
- Licencia de la grabación: CC0 1.0, dominio público (Musopen)
- Fecha de descarga: 11 de noviembre de 2026

### 3. 03-chopin-nocturno-op9-no2.mp3 — 2 minutos 30 segundos, 2,29 MB
- Compositor: Frédéric Chopin
- Obra: Nocturno en mi bemol mayor, Opus 9 número 2
- Intérprete: Frank Levy
- Fuente: https://commons.wikimedia.org/wiki/File:Nocturne_in_E_flat_major,_Op._9_no._2.mp3
- Licencia de la grabación: dominio público (Musopen)
- Fecha de descarga: 11 de noviembre de 2026

### 4. 04-chopin-preludio-op28-no15-gota-de-lluvia.mp3 — 2 minutos, 1,83 MB
- Compositor: Frédéric Chopin
- Obra: Preludio en re bemol mayor, Opus 28 número 15, "Gota de lluvia" (solo el inicio tranquilo)
- Intérprete: no indicado en el archivo
- Fuente: colección Musopen, "The Complete Chopin Collection", Internet Archive, CC0 1.0
- Enlace de la colección: https://archive.org/details/musopen-chopin
- Enlace directo del archivo: https://archive.org/download/musopen-chopin/Prelude%20Op.%2028%20no.%2015.mp3
- Licencia de la grabación: CC0 1.0, dominio público
- Fecha de descarga: 11 de noviembre de 2026

### 5. 05-mozart-sonata-k545-allegro.mp3 — 2 minutos 12 segundos, 2,02 MB
- Compositor: Wolfgang Amadeus Mozart
- Obra: Sonata para piano número 16 en do mayor, K. 545, "Sonata fácil", primer movimiento, Allegro (completa)
- Intérprete: Robin Alciatore
- Fuente: https://commons.wikimedia.org/wiki/File:Wolfgang_Amadeus_Mozart_-_sonata_no._16_in_c_major,_k.545_%27sonata_facile%27_-_i._allegro.ogg
- Licencia de la grabación: dominio público (Musopen)
- Fecha de descarga: 11 de noviembre de 2026
- Nota: es la pista más alegre y movida del paquete; sirve para escenas de felicidad.

### 6. 06-schubert-impromptu-op90-no3.mp3 — 2 minutos 30 segundos, 2,29 MB
- Compositor: Franz Schubert
- Obra: Impromptu número 3 en sol bemol mayor, Opus 90, D. 899
- Intérprete: Chiara Bertoglio
- Fuente: https://commons.wikimedia.org/wiki/File:Schubert%27s_Impromptu_no._3_in_G-flat_major,_D.899_-_Chiara_Bertoglio.ogg
- Página en Musopen: https://musopen.org/music/6961-4-impromptus-d-899-op-90/
- Licencia de la grabación: Creative Commons Atribución 3.0 (CC BY 3.0)
- Atribución: "Franz Schubert, Impromptu Op. 90 No. 3, interpretado por Chiara Bertoglio, CC BY 3.0"
- Fecha de descarga: 11 de noviembre de 2026

### 7. 07-bach-variaciones-goldberg-aria.mp3 — 2 minutos 30 segundos, 2,29 MB
- Compositor: Johann Sebastian Bach
- Obra: Variaciones Goldberg, Aria
- Intérprete: no indicado en el archivo (versión Musopen)
- Fuente: https://commons.wikimedia.org/wiki/File:Bach,_Goldberg_Variations,_Aria_(Musopen_version).ogg
- Origen de la grabación: colección Musopen en Internet Archive, https://archive.org/details/MusopenCollectionAsFlac
- Licencia de la grabación: CC0 1.0, dominio público
- Fecha de descarga: 11 de noviembre de 2026

### 8. 08-satie-gimnopedia-no1.mp3 — 2 minutos 30 segundos, 2,29 MB
- Compositor: Erik Satie
- Obra: Gimnopedia número 1, Lento y doloroso
- Intérprete: Robin Alciatore
- Fuente: https://commons.wikimedia.org/wiki/File:Erik_Satie_-_gymnopedies_-_la_1_ere._lent_et_douloureux.ogg
- Licencia de la grabación: dominio público (Musopen)
- Fecha de descarga: 11 de noviembre de 2026

## Lo que no se pudo verificar

- Tchaikovsky: no se incluyó en esta primera prueba. No se encontró
  una grabación de piano solo de Tchaikovsky en Musopen con licencia
  verificable y descarga estable. La página de Musopen de "Las
  estaciones" solo mostraba partituras, y otras grabaciones venían
  del Archivo Europeo, con origen poco claro. Queda pendiente para
  una segunda versión del paquete.
- Tampoco se usó ninguna pista de YouTube, porque ahí no se sabe
  quién grabó ni con qué licencia, y eso es justo lo que Dionisio
  pidió evitar.

## Uso

Las 7 pistas en dominio público o CC0 se pueden usar libremente,
incluso en audios que se compartan. La pista 6, de Schubert, pide
atribución a Chiara Bertoglio: basta con nombrar a la intérprete
y la licencia CC BY 3.0 cuando se comparta.
