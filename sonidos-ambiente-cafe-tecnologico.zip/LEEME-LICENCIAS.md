# Sonidos de ambiente - Cafe Tecnologico
Fecha de descarga: 2026-11-09
Total: 98 archivos, 19.4 MB sin comprimir
Limite pedido: menos de 25-26 MB

Categorias:
- Lluvia: ambiente-rain.ogg, ambiente-thunder.ogg, doever-heavyRain.ogg, doever-lightRain.ogg, doever-thunder.ogg, flowdesk-rain.mp3
- Parque / naturaleza: ambiente-forest.ogg, ambiente-birds.ogg, ambiente-cicadas.ogg, ambiente-crickets.mp3, ambiente-grass.ogg, ambiente-water.ogg, ambiente-waves.ogg, doever-birds.ogg, doever-crickets.ogg, doever-stream.ogg, flowdesk-forest.mp3, flowdesk-river.mp3, flowdesk-waves.mp3
- Cafeteria: ambiente-town.ogg, doever-cafe.ogg, flowdesk-cafe.mp3
- Oficina / interior: ambiente-indoor.ogg, doever-office.ogg, doever-keyboard.ogg
- Noche / suspenso / terror: ambiente-cave.ogg, ambiente-fire.ogg, ambiente-wind.ogg, doever-wind.ogg, doever-fireplace.ogg, flowdesk-night.mp3, flowdesk-fireplace.mp3, emocion-riser-*.ogg, emocion-faller-*.ogg, emocion-bass-*.ogg, emocion-cinematic-*.ogg
- Felicidad: emocion-celebration-*.ogg, emocion-shimmer-*.ogg
- Tristeza / calma: emocion-faller-*.ogg, emocion-tone-*.ogg
- Ficcion / magia: emocion-shimmer-*.ogg, emocion-sting-*.ogg, emocion-tone-*.ogg
- Tren / viaje: doever-train.ogg, doever-ocean.ogg, doever-vinyl.ogg

Fuentes y licencias:
1. Terrarium - https://github.com/BrenoBertucci/Terrarium - assets/audio/CREDITS.md - CC0 1.0, dominio publico, sin atribucion. Archivos ambiente-*.ogg/mp3
2. FlowDesk - https://github.com/Sheryar-Ahmad/FlowDesk - frontend/public/audio/README.md - CC0 1.0. Archivos flowdesk-*.mp3
3. Doever - https://github.com/felipilloff/doever_app - assets/audio/ATTRIBUTION.md y recordings.json, verificado 2026-09-28. Archivos doever-*.ogg, convertidos de WAV 44.1 kHz mono 24 s a OGG Vorbis q4 mono 44.1 kHz.
   - CC0 1.0: birds (kvgarlic), heavyRain (NachtmahrTV), keyboard (paulocorona), office (simonjeffery13), stream (gluckose), thunder (TRP), wind (felix.blume)
   - Dominio publico: cafe (stephan, SoundBible), crickets (Lisa Redfern), fireplace (ezwa)
   - CC BY 4.0 (requiere atribucion): lightRain (alex36917), ocean (Luftrum)
   - CC BY 3.0 (requiere atribucion): train (SDLx)
   - MIT, original generado: vinyl (Doever)
4. SFX Kit - https://github.com/wyzowl/sfx-kit - CC0. Archivos emocion-*.ogg, convertidos de WAV estereo a OGG Vorbis q4 mono 44.1 kHz. Categorias: celebration, shimmers, risers-and-fallers, booms-and-bass, cinematic-hits, logo-stings, tones, impacts.

Nota: la licencia es sobre la grabacion, no sobre la lluvia o el parque en si. Guardar este archivo con el proyecto como evidencia para Claude.
